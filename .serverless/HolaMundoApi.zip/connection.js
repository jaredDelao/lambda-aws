// const mongoose = require('mongoose');
// mongoose.set('useFindAndModify', false);

// mongoose
//     .connect(
//         'mongodb+srv://jareddelao:bWlRWhgRKu9Z2nCv@ecommerce1.mcoiu.mongodb.net/e-commerce?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true, },
//         function(err) {
//             if (err) {
//                 return console.dir(err);
//             }
//         })